# AISLER quotation metadata correction — 20 October 2026

**Based on** the previously delivered Audio_HAT_AISLER_MPN_ready.zip, which in turn was derived from the 19 October `Audio_HAT(4).kicad_sch`. This may not contain any KiCad edits you made locally after that upload. Back up and reconcile before replacing any newer file.

This edition contains **no circuit or footprint changes**. The connectivity, values, nets, coordinates, library definitions, and existing KiCad DNP settings were preserved. Changes are limited to:

1. **Remove the `MPN` property entirely for standard resistors** R2, R3, R4, R5, R7, R8, R11–R16, R17–R19 and jumper JP1. This lets AISLER attempt its *value fallback* as it did before the over-specific exact part numbers were added. It does NOT preapprove any proposed substitutes. Verify resistance, tolerance, power, temperature rating, footprint and sourcing before accepting.
2. **Keep exact manufacturer part numbers for every capacitor**, both ferrite beads, protection diodes, op amps, ADC and the LT3042, plus precision resistor R1 and input bias resistor R6.
3. **Mark C20, C21 and J1–J6 as `DNP`** for the factory assembly. Their footprints and connections remain on the physical board, so those components can still be soldered later. R9/R10 were already DNP and remain unchanged.

### Important unresolved sourcing

- **C16/C17**: Existing exact `1206B475K500NT` MPN did not automatically match at AISLER. Leave unassigned until AISLER can supply the exact part or a separately verified equivalent (4.7 uF, 50 V, dielectric, effective capacitance vs DC bias, physical fit, and line-input low-frequency response). Do not approve a generic 4.7 uF ceramic blindly.
- **D1/D2**: Exact Nexperia `PESD5V0U1BB,115` was previously manually searchable but did not auto-match. Keep manufacturer part number and select the exact listing if manual assignment is needed.
- **R2 and R7/R8**: Their 33-ohm and 5.1-kohm values are not necessarily covered by AISLER's E48 Smart Match restriction; value fallback was preferable because it matched them in the first quotation. Do not alter circuit values merely for matching.
- **IC1** and **U1**: Exact TI TAC5212IRGER and Analog Devices LT3042EMSE#PBF preserved. Verify live inventory and price.
- **C18/C19**: Exact Panasonic EEU-FR1A681 retained and intended for factory assembly; check AISLER's through-hole assembly support and polarity.

### Use

- This file is **a quotation-only metadata revision, not approval for manufacture**.
- Open the schematic in KiCad 10 after backing up the current project. Compare against your *latest* schematic first if it has been edited since October 19.
- Update PCB from schematic (F8). Check **Update footprint fields from symbols** AND **Remove footprint fields not found in symbols** (this second KiCad 10 option is needed to remove the stale resistor MPNs from PCB footprints). Avoid replacing the custom IC1 footprint geometry, especially pad 25. Review proposed changes, save and rerun ERC/DRC.
- Verify a generic resistor's PCB footprint no longer has an `MPN` property, and C20/C21, J1–J6 have DNP enabled, **before uploading the updated `.kicad_pcb`** to a fresh AISLER project. (Existing AISLER project revisions may retain previous assembly decisions.)
- On AISLER, compare the assignments individually and *do not* click Confirm All until they meet the electrical requirements.

The edited schematic was checked for balanced symbol records and exact preservation of all non-target symbol content; no KiCad CLI ERC/DRC was available in this environment.
