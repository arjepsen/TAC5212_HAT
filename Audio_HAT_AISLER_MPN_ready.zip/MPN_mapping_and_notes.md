# Audio HAT — AISLER MPN metadata audit

Basis: user-supplied `Audio_HAT(4).kicad_sch` (19 October 2026). This is a metadata-only change.

- 54 unique physical references, represented by 56 symbol units (U2 has three units).
- Added a hidden `MPN` property to every physical symbol unit.
- 48 references have a nonempty exact manufacturer part number, grouped into 28 unique MPNs.
- J1–J6 have intentionally empty MPNs: J1 is an underside hand-soldered socket with an insufficiently specific existing part designation; J2–J6 are wire-solder connection footprints, not purchasable parts.
- No modifications to any existing schematic content other than adding MPN properties. All original properties, DNP flags, values, references, footprints, pin numbers, nets and wires are byte-for-byte unchanged.
- The original KiCad DNP flags are **R9 and R10 only**. C20/C21 and J1–J6 are **not** marked DNP in this input. Manually exclude them for the current assembly unless you intentionally change their DNP flags.

## Part number mapping

| References | Manufacturer | MPN |
|---|---|---|
| C1, C4, C5, C7, C9, C13 | Samsung Electro-Mechanics | `CL21A106KAYNNNE` |
| C2, C6, C8, C10, C12 | Yageo | `CC0603KRX7R9BB104` |
| C3 | Samsung Electro-Mechanics | `CL21A475KAQNNNE` |
| C11 | Samsung Electro-Mechanics | `CL21B105KBFNNNE` |
| C14 | FH | `1206CG104J500NT` |
| C15 | Samsung Electro-Mechanics | `CL10C220JB8NNNC` |
| C16, C17 | FH | `1206B475K500NT` |
| C18, C19 | Panasonic | `EEU-FR1A681` |
| C20, C21 | Panasonic | `EEU-FR1C101` |
| D1, D2 | Nexperia | `PESD5V0U1BB,115` |
| FB1 | Murata | `BLM21PG221SN1D` |
| FB2 | Murata | `BLM18SP601SN1D` |
| IC1 | Texas Instruments | `TAC5212IRGER` |
| JP1 | UNI-ROYAL | `0603WAF0000T5E` |
| R1 | Yageo | `RT0603BRD0733K2L` |
| R2 | UNI-ROYAL | `0402WGF330JTCE` |
| R3, R4 | UNI-ROYAL | `0603WAF1002T5E` |
| R5 | UNI-ROYAL | `0603WAF1001T5E` |
| R6 | UNI-ROYAL | `0603WAF1004T5E` |
| R7, R8 | UNI-ROYAL | `0603WAF5101T5E` |
| R9 | Yageo | `RC0603FR-07750KL` |
| R10 | UNI-ROYAL | `0603WAF3303T5E` |
| R11, R13, R14, R17, R18 | UNI-ROYAL | `0402WGF1002TCE` |
| R12 | UNI-ROYAL | `0603WAF1003T5E` |
| R15, R16 | UNI-ROYAL | `0402WGF1000TCE` |
| R19 | UNI-ROYAL | `0402WGF1003TCE` |
| U1 | Analog Devices | `LT3042EMSE#PBF` |
| U2 | Texas Instruments | `OPA2365AIDR` |

## AISLER / external sourcing status

- **U1 LT3042EMSE#PBF**: AISLER selection screen displayed genuine Analog Devices part in the correct MSOP-10-EP package with green availability and €3.78 displayed at time of screenshot.
- **D1/D2 PESD5V0U1BB,115**: AISLER search screen showed an exact Nexperia SOD-523 listing with green availability.
- **FB1 BLM21PG221SN1D**: AISLER previously allowed its exact Murata selection, but live inventory and cost were not established.
- **IC1 TAC5212IRGER**: AISLER previously auto-selected the exact Texas Instruments codec; inventory was not individually confirmed there. Mouser recently listed stock.
- **C18/C19 EEU-FR1A681**: Mouser lists the exact Panasonic radial 680 µF capacitor in stock. AISLER availability and through-hole assembly pricing remain unverified.
- All other MPNs came from the uploaded schematic’s existing Manufacturer part fields. They were not replaced with unsupported alternatives. AISLER does not expose a publicly searchable, complete live inventory here, so **an MPN property is not an assurance of stock**.

## Next step in KiCad 10

1. Back up the existing `Audio_HAT.kicad_sch` within your project folder.
2. Rename this edited schematic to `Audio_HAT.kicad_sch` in that same project folder and open it in KiCad.
3. In Schematic Editor use **Tools → Update PCB from Schematic (F8)**; ensure **Update footprint fields from symbols** is enabled. Review the changes before applying. Do not use **Update Footprints from Library**, which could overwrite IC1 custom paste apertures.
4. Save PCB, run ERC/DRC, then check an individual PCB footprint’s properties to confirm that the new `MPN` field is present.
5. Upload the **updated `.kicad_pcb`** to AISLER as a new project and verify assignments; AISLER matches MPNs exactly, so any unrecognized or out-of-stock part still requires manual review.

## Limitations

- No full KiCad desktop ERC was run on the generated file here; the original symbol blocks were verified byte-for-byte identical after removing exactly the added fields.
- The uploaded input includes only the schematic, so no PCB files were modified.
- Manufacturer/distributor stock can change; verify the completed AISLER quote before ordering.
