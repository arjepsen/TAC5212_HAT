AISLER v4 — *DRAFT SOURCING VARIANT; NOT MANUFACTURING SIGN-OFF*

Date researched: 2026-10-20.

AISLER reports it typically does not maintain its own fixed inventory. It sources from supported distributors, including DigiKey. This version changes the AISLER-facing MPN fields and matching manufacturer fields for 15 ordinary resistors plus JP1, replacing unrecognized Smart Match descriptions with exact, DigiKey-stocked MPNs. See SOURCING.csv for the 9 manufacturer part numbers, values, footprints and direct product URLs. They are not verified as automatically assignable in your logged-in AISLER project; that requires a new upload and parts/stock review. Stock can change.

Preserved exactly: All resistor values, circuit connections, footprint IDs and Do Not Populate flags. R1 and R6 are deliberately NOT changed. No capacitors, ICs, ferrite beads or protection diodes are changed. Four 0402 resistors retain 63mW ratings equivalent to the prior 62.5mW choices. R7/R8 use Vishay 5.1 kΩ 1% 0603 at 0.125W (greater power rating). R2 uses 33 Ω 1% 0402 instead of prior 5%; this is no loss of precision.

WARNING: The historic KiCad fields named `JLCPCB part` remain unchanged as ALTERNATE sourcing references for a separate JLCPCB order. They refer to the *earlier* UNI-ROYAL parts, not the Yageo/Vishay parts now placed in `MPN` and `Manufacturer part`. For ordering on AISLER, use `MPN`. Do not create a combined manufacturing BOM by treating both fields as the same MPN.

Outstanding: C16/C17 (4.7 µF 50 V X7R, 1206, FH 1206B475K500NT) are unassigned. KEMET C1206C475K5RACAUTO is stocked by DigiKey but is NOT approved as equivalent without checking capacitance at bias, acoustic/nonlinear effects and mounting geometry. D1/D2 exact Nexperia PESD5V0U1BB,115 is stocked by AISLER's prior search screenshot even though DigiKey currently shows stock 0; do not change it. The 0-ohm JP1 is now Yageo RC0603JR-070RL.

No electrical change. Test by importing the updated PCB into a fresh AISLER project, then verify part selections and assembly quote. If local schematic or PCB was updated since AISLER v3, compare/reconcile before overwriting.
